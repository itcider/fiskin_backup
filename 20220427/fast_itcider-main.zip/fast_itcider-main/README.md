# fast_itcider
fast_itcider

스킨명 : fast itcider <br>
버전 : v4.4<br>
제작자 : itcider 쉽고 시원한 it<br>
제작자 웹사이트 : itcider.com<br>
사용 조건 : itcider license<br>
사용 주의점 :<br>
ㄴ주석 수정 및 삭제 불가<br>
ㄴfi스킨 문구 삭제 불가<br>
ㄴ스킨은 무제한적으로 사이트에 적용 가능<br>
ㄴ재배포 및 코드 무단 사용 절대 불가<br>
ㄴitcider 공식 웹사이트에서만 배포 가능<br>
위 주의사항을 어기실 경우 사용 불가합니다.<br>

티스토리 글쓰는데만 집중하세요! - 티스토리 무료 스킨 [fi스킨]
https://itcider.com/903


 
참조 소스 및 기여

 

    티스토리 포트폴리오 스킨

https://www.tistory.com/skin/xf_Portfolio

    web share api

https://blog.naver.com/PostView.nhn?blogId=zgabriel&logNo=221846990627 

https://wooncloud.tistory.com/12

    css 및 메뉴얼

https://developer.mozilla.org

https://stackoverflow.com/

    lazyload

https://marshallku.com/web/tips/%ED%8B%B0%EC%8A%A4%ED%86%A0%EB%A6%AC%EC%97%90%EC%84%9C-lazy-load-%EC%82%AC%EC%9A%A9%ED%95%98%EA%B8%B0

https://blogpack.tistory.com/817

    이미지 리소스

https://itcider.com/(itcider 자체 제작 이미지 포함)

https://pixabay.com/vectors/hexagon-symbol-gui-internet-2307352/

https://pixabay.com/vectors/link-hyperlink-chain-linking-6931554/

    티스토리 치환자

https://tistory.github.io/document-tistory-skin/common/basic.html

    우클릭 및 저작권 보호

https://gist.github.com/ab-c-d/7aa98987589466eee696952e154c98e1

    jquery 목차

https://www.codingfactory.net/12114

    fi스킨 기여자

https://urliveblogger.blogspot.com/


*itcider의 모든 글과 리소스, 파일은 itcider에 귀속되며, itcider의 허가 없는 무단 복제 및 전재는 저작권법 및 부정경쟁방지법에 의해서 경고 또는 처벌조치될 수 있습니다.* https://itcider.com/903 [copyright 2020-2022 itcider.com 모든 판권 보유]
